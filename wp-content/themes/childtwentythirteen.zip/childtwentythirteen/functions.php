<?php
function my-theme-enqueue-styles()
{

	$parent_style = 'parent-style'; // 
	This is 'twentythirteen-style'for the Twenty Thirteen theme.
	wp_enqueue_style ($parent_style, get template_directory_uri() .'/
		style.css');

	wp_enqueue_style( $child-style', get_stylesheet_directory_uri() .'/style.css',
		array( $parentstyle ),
		wp_get_theme()->get('Version');

} add_action('wp_enqueue_scripts','my_theme_enqueue_styles');
@import url('../twentythirteen/style.css');
@import url('https://fonts.googleapis.com/css?family=Fira+Sans+Condensed:400,4001,700|Titillium+Web:400,700');

?>